package com.faith.app.service;

import java.util.List;

import com.faith.app.entity.Student;

public interface IStudentService {

	//List
	public List<Student> getStudents();
}
