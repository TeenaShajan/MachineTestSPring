package com.faith.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ScholarshipManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(ScholarshipManagementApplication.class, args);
	}

}
